<?php
session_start();

// Retrieve the entered OTP and generated OTP from the form submission
$enteredOTP = $_POST['arya'];
$generatedOTP = $_SESSION['generatedOTP'];

// Compare the entered OTP with the generated OTP
$verificationStatus = ($enteredOTP == $generatedOTP) ? "success" : "error";
?>

<!DOCTYPE html>
<html>
<head>
    
    <title>OTP Verification</title>
    <link rel="stylesheet" type="text/css" href="otpverification_styles.css">

</head>
<body>
    <div class="container">
        <h2>OTP Verification</h2>
        <?php if ($verificationStatus === "success") { ?>
            <p class="success">OTP verification successful!</p>
            <?php exec("python facemask.py") ?>

        <?php } else { ?>
            <p class="error">The OTP you entered is incorrect</p>
            <div class="warning-container">
                <h3>Steps to take</h3>
                <p>The OTP you entered is incorrect. Please follow these steps:</p>
                <ol>
                    <li>Double-check the OTP you received and ensure it is entered correctly.</li>
                    <li>Make sure you are using the correct OTP for this verification process.</li>
                    <li>If the issue persists, contact customer support for further assistance.</li>
                    <li>Please note that if the card does not belong to you, do not retry as your account may get blocked.</li>
                </ol>
            </div>

        <?php } ?>
    </div>
</body>
</html>
