<!DOCTYPE html>
<html>

<head>
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="login_styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

</head>

<body>
    <form action="otpPage.php" name="myform" method="post" onsubmit="return cardnumber()">

        <h1>Banking Portal</h1>

        <div class="input-container">
            <label for="uname" class="center-label">Enter your 16 digit Card Number</label>
            <input type="text" name="uname" id="card" placeholder="Card Number" pattern="^[0-9]{4}\s?[0-9]{4}\s?[0-9]{4}\s?[0-9]{4}$" required>
            
        </div>

        <input type="submit" name="register" value="SEND OTP">
        <div class="warning-container">
            <br/><span id="numloc"></span>
        </div>

    </form>
</div>

<script>

$(document).ready(function() {

  function cardnvalidate() {
    var x = $('#card').val();
    var length = x.toString().length;

    if (isNaN(x)) {
      $("#numloc").html("Enter Numeric value only").css("color", "red");
      return false;
    }

    if (length > 16 || length < 16) {
      $("#numloc").html("Number of digits is not 16").css("color", "red");
      return false;
    }else{
        $("#numloc").html("Card number is valid").css("color", "green");
        return true;
    }
  }

  $("#card").on("keyup", function() {
    cardnvalidate();
  });
});

</script>

</body>

</html>
