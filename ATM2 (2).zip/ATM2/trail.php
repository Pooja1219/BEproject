<?php

echo shell_exec("python otp(mail).py")

?>