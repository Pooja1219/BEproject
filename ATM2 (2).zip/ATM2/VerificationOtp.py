import sys
def verify_otp(entered, generated):
    if str(entered) == generated:
        print("OTP verified successfully!")
    else:
        print("OTP verification failed!")

if __name__ == "__main__":
    entered = sys.argv[1]
    generated = sys.argv[2]
    
    verify_otp(entered, generated)