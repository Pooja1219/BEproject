<!DOCTYPE html>

<html>

<head>

    <title>OTP</title>

    <link rel="stylesheet" type="text/css" href="style.css">
    
   
</head>
<body>


     <form action="OtpVerification.php" name="myform" method="post">
     
     <?php
        require("C:\xampp\htdocs\ATM2\ATM2\atmusers.sql");
        session_start();
        $name = $_SESSION['uname'];
        if ( isset($_POST['uname'])){
            $name = $_POST['uname'];
            
        }
        $sql = "SELECT * FROM userdetails WHERE CardNo='$name'";
        $result = mysqli_query($conn, $sql);
        $info = mysqli_fetch_array( $result );
        $First=$info['FirstName'];
        $last=$info['LastName'];
        $email = $info['Email'];
        mysqli_close($conn);
        $generatedOtp=exec("python mailViaOtp.py  $email");
        
       
       

    ?>  
     <h2>Welcome <?php echo $First ; echo " ";  echo $last;?></h2>

        <?php if (isset($_GET['error'])) { ?>

            <p class="error"><?php echo $_GET['error']; ?></p>

        <?php } ?>

        <label>OTP</label>

        <input type="text" name="arya" id="card" placeholder="Enter OTP"><span id="numloc"></span><br>

        <button type="submit" name="submit">Submit</button>

     </form>

     <?php
      
                if(!isset($_SESSION)) 
                { 
                    session_start(); 
                } 
                $name = $_GET['arya'];  

                $_SESSION['arya'] = $name;
                $_SESSION['gen'] = $generatedOtp;
                echo $generatedOtp;

	use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
 
    //Load Composer's autoloader
    require 'vendor/autoload.php';
 
    if (isset($_POST["register"]))
    {
        
 
        //Instantiation and passing `true` enables exceptions
        $mail = new PHPMailer(true);
 
        try {
            //Enable verbose debug output
            $mail->SMTPDebug = 0;//SMTP::DEBUG_SERVER;
 
            //Send using SMTP
            $mail->isSMTP();
 
            //Set the SMTP server to send through
            $mail->Host = 'smtp.gmail.com';
 
            //Enable SMTP authentication
            $mail->SMTPAuth = true;
 
            //SMTP username
            $mail->Username = 'your_email@gmail.com';
 
            //SMTP password
            $mail->Password = 'your_password';
 
            //Enable TLS encryption;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
 
            //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
            $mail->Port = 587;
 
            //Recipients
            $mail->setFrom('your_email@gmail.com', 'your_website_name');
 
            //Add a recipient
            $mail->addAddress($email, $name);
 
            //Set email format to HTML
            $mail->isHTML(true);
 
            $verification_code = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
 
            $mail->Subject = 'Email verification';
            $mail->Body    = '<p>Your verification code is: <b style="font-size: 30px;">' . $verification_code . '</b></p>';
 
            $mail->send();
            // echo 'Message has been sent';
 
            $encrypted_password = password_hash($password, PASSWORD_DEFAULT);
 
            // connect with database
            $conn = mysqli_connect("localhost:8889", "root", "root", "test");
 
            // insert in users table
            $sql = "INSERT INTO users(name, email, password, verification_code, email_verified_at) VALUES ('" . $name . "', '" . $email . "', '" . $encrypted_password . "', '" . $verification_code . "', NULL)";
            mysqli_query($conn, $sql);
 
            header("Location: email-verification.php?email=" . $email);
            exit();
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
	}
                
     ?>

</body>


</html>
