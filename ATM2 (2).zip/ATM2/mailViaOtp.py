# Import the necessary libraries
import sys
import smtplib
import random

def send_email(email, otp):

# Set up the email account credentials
    email_address = "shreepooja.1912@gmail.com"  # replace with your email address
    email_password = "gulturwrojinsalb"  # replace with your email password

    # Set up the message to send
    to_email_address = sys.argv[1] 
    otp = sys.argv[2]  # replace with the recipient's email address

    #print(otp)# generate a 6-digit OTP
    subject = "Your One-Time Password"
    message = f"Dear user,\n\nYour OTP is: {otp}\n\nBest regards,\nThe team"

    # Set up the SMTP server
    smtp_server = "smtp.gmail.com"
    smtp_port = 587

    # Start the SMTP server and login to the email account
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(email_address, email_password)

    # Send the message
    server.sendmail(email_address, to_email_address, f"Subject: {subject}\n\n{message}")

    # Quit the SMTP server
    server.quit()
    

    # Prompt the user to enter the OTP

    # Verify the OTP
    #subprocess.call(["php","OtpVerification.php",otp])

if __name__ == "__main__":
    email = sys.argv[1]
    otp = sys.argv[2]
    
    send_email(email, otp)