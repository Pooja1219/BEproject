<!DOCTYPE html>

<html>

<head>

    <title>OTP</title>

    <link rel="stylesheet" type="text/css" href="otppage_styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    
   
</head>
<body>
<div class="greeting-message" id="greeting-message">
        <div class="greeting-message-content">
            <p>The OTP has been sent to your registered email address.</p>
        </div>
    </div>


<form action="otpVerification.php" name="myform" method="post">
        <?php
        require("../ATM2/DB.php");
        session_start();
        if (isset($_POST['uname'])) {
            $name = $_POST['uname'];
        }

        function generateOTP()
        {
            $otp = rand(100000, 999999); // Generate a random 6-digit number
            return $otp;
        }

        $generatedOTP = generateOTP();
        $_SESSION['generatedOTP'] = $generatedOTP;
        $sql = "SELECT * FROM userdetails WHERE CardNo='$name'";
        $result = mysqli_query($conn, $sql);
        $info = mysqli_fetch_array($result);
        $First = $info['FirstName'];
        $last = $info['LastName'];
        $email = $info['Email'];

        //sending mail
        exec("python mailViaOtp.py $email $generatedOTP");

        $sql2 = "UPDATE userdetails SET otp = '$generatedOTP' WHERE CardNo='$name'";
        $conn->query($sql2);

        mysqli_close($conn);
        ?>

        <h2>Welcome <?php echo $First; echo " ";  echo $last;?></h2>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>

        <input type="text" name="arya" id="entered_otp" placeholder="Enter OTP">
        <br\>
        <span id="numloc"></span>
        <br\>
        <input type="submit" id="otpSubmit" name="register" value="Verify OTP">

    </form>

<script>

window.onload = function() {
            var greetingMessage = document.getElementById('greeting-message');
            setTimeout(function() {
                greetingMessage.style.top = '0'; // Show the message by setting top position to 0
            }, 500); // Delay the animation for 0.5 seconds (adjust as desired)
        };

$(document).ready(function() {
    function verify(generatedOTP) {
        var x = $("#entered_otp").val();
        var length = x.toString().length;

        if (isNaN(x)) {
          $("#numloc").html("Enter Numeric value only").css("color", "red");
          return false;
        }

        if (length !== 6) {
          $("#numloc").html("Length of OTP should be 6").css("color", "red");
          return false;
        }

        if (length == 6) {
          $("#numloc").html("Click on Verify OTP for validation").css("color", "green");
          return true;
        }
    }


  $("#entered_otp").on("keyup", function() {
    verify(<?php echo json_encode($generatedOTP); ?>);
  });


  (function() {
     setTimeout(function(){ 
         //disable the button with id="submitbutton"
         document.getElementById('#otpSubmit').disabled = true;
         alert("Time out!"); 
      }, 1800000);

})();




});

</script>


</body>


</html>